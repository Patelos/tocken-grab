What to do if you have been a victim of someone using our software;

Win + R + %appdata% /Microsoft/Windows/Start Menu/Programs/Startup 

if there is a foreign file in the folder delete it.

Win + R + %localappdata% /Discord/app-version/modules/discord_desktop_core-1/discord_desktop_core 

If the index.js file is larger than 1KB, right click the index.js file and open it with notepad and delete everything in it


A few things you can do to avoid being a victim;

In our code, we have 2 list variables under the name of blacklist. If you put the names in the strings in the variable on your computer, the software will never run on your computer.

Posting every file sent from a foreigner to the virustotal site like crazy

Using your computer with Windows 11. If the person in front of you only knows how to use the software, no one can easily infect you if you are using windows 11.

Adding 2FA verification to all your important accounts. This full time not working but can protect your account from being stolen.